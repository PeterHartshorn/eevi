<?php

$applicantID = null;
$gameID = null;
$timeStarted = null;

function sendRequest($method, $url, $data, $contentType="application/json", $verbose=false)
{
	$login = "eevi applicant";
	$password = "love to code";

	$encoded = $data; //json_encode($data);
	$len = strlen($encoded);

	$ch = curl_init();
	if ($verbose) curl_setopt($ch, CURLOPT_VERBOSE, true);
	if ($method === "POST") curl_setopt($ch, CURLOPT_POST, 1);
	else if ($method === "PUT") curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
	else die("Unknown transfer method $method\n");

	curl_setopt($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	curl_setopt($ch, CURLOPT_USERPWD, "$login:$password");
	curl_setopt($ch, CURLOPT_POSTFIELDS, $encoded);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: $contentType"));

	$result = curl_exec($ch);
	curl_close($ch);
	return $result;
}

function authenticateUser($preferredName, $emailAddress)
{
	$result = sendRequest("POST", "https://game.eevi.life/apply", json_encode(Array(
		"PreferredName" => $preferredName,
		"EmailAddress" => $emailAddress
	)));

	if ($result === "Sorry, try again.") die("failed to authenticate\n");

	$decoded = json_decode($result);
	return $decoded->ApplicantID;
}

function registerForGame($applicantID)
{
	global $timeStarted;

	$result = sendRequest("POST", "https://game.eevi.life/guess", json_encode(Array(
		"ApplicantID" => $applicantID
	)));

	if ($result === "Sorry, try again.") die("failed to register for the game\n");

	$decoded = json_decode($result);
	$timeStarted = $decoded->TimeStarted;
	var_dump($result);
	return $decoded->GameID;
}

function performGameStep($guess)
{
	global $applicantID, $gameID;

	$result = sendRequest("PUT", "https://game.eevi.life/guess", json_encode(Array(
		"ApplicantID" => $applicantID,
		"GameID" => $gameID,
		"Guess" => $guess
	)));

	if ($result === "Sorry, try again.") die("failed to execute the game step\n");

	$decoded = json_decode($result);
	return $decoded;
}

function playGame()
{
	global $applicationID, $gameID;

	$max = 1000000;
	$min = 0;
	$currentGuess = 500000; // start at the middle
	$won = false;
	$res = null;
	$direction = "Higher";

	while ($won === false) {
		echo "guessing $currentGuess\n";
		$res = performGameStep($currentGuess);
		if ($res->Won) {
			echo "Game won...\n";
			$won = true;
		} else if ($res->HigherLower === "Higher") {
			echo "^ $min $currentGuess $max\n";
			// work around for the possible rounding bug.
			if ($max === $currentGuess) $max = 1000000;
			$nextGuess = $currentGuess + ceil(($max - $currentGuess)/ 2);
			$min = $currentGuess;
			$currentGuess = $nextGuess;
		} else if ($res->HigherLower === "Lower") {
			echo "v $min $currentGuess $max\n";
			// work around for the possible rounding bug.
			if ($min === $currentGuess) $min = 0;
			$nextGuess = $min + floor(($currentGuess - $min)/ 2);
			$max = $currentGuess;
			$currentGuess = $nextGuess;
		} else {
			echo "I do not think it means what you think it means " . $res->HigherLower . "\n";
		}
	}

	return $res;
}

function submitPack($gameResult)
{
	global $applicantID, $gameID;

	$packUrl = "https://raw.githubusercontent.com/PeterHartshorn/eevi/master/pack.zip";

	$result = sendRequest("POST", "https://game.eevi.life/submit_pack", json_encode(Array(
		"ApplicantID" => $applicantID,
		"GameID" => $gameID,
		"PackURL" => $packUrl,
		"PackInstructions" => "Download the Zip file and extract, run the eevi.php script using 'php ./eevi.php'"
	)));

	if ($result === "Sorry, try again.") die("failed to submit the pack\n");

	$decoded = json_decode($result);
	return $decoded;
}

$applicantID = authenticateUser("Peter Hartshorn", "phartshorn@programmer.net");
if ($applicantID) {
	$gameID = registerForGame($applicantID);
	if ($gameID) {
		$res = playGame();
		$res = submitPack($res);
		var_dump($res);
	}
}
?>
